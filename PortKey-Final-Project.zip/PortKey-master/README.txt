This is a simple Project for booking cab servies in campus lifestyle.

What's the Need?
Many of the residents oftern visit comman places around at weekend.
Either they have to catch a train or bus or they conatact a cab driver,which cost them their time and money a lot.


The Solution
"PortKey"
it's a cab based service which books the cab or finds weather a cab is booked or not already.
IF cab is booked already than you can join the other clients of the cab to go with them at the same destination.
IF not than you can book our own cab and also invite other peoples too.