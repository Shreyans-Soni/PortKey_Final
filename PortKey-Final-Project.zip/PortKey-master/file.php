<?php
echo "<h1>Screen Resolution:</h1>";
echo "Time  : ".$_GET['time']."<br>";
echo "Distance : ".$_GET['unit']."<br>";
echo "<script>window.close();</script>";
?>
