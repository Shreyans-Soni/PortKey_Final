<?php

echo "<h1>Screen Resolution:</h1>";
echo "Time  : ".$_GET['time']."<br>";
echo "Distance : ".$_GET['unit']."<br>";
//$unit = $_GET['unit'];
//$time = $_GET['time'];
/*
include('/var/www/html/PortKey-master/session_bus.php');
$sql_new = "update bus set distance = '$unit', time = '$time' inner join user_info on user_info.bus_id = bus.bus_id inner join authentication on authentication.user_id = user_info.user_id where authentication.user_name = '$login_session'";
if ($db->query($sql_new) === TRUE) {
    echo "New distance and time successfully updated.";
} else {
    echo "Error: " . $sql_new . "<br>" . $db->error;
}
*/
echo "<script>window.close();</script>";
?>
